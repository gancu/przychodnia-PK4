#include <map>
#include <set>
#include <string>
#include "interfejs.h"
 
using namespace std;

int main(int argc, char** argv)
{
	interfejs in;

	in.Program(argc, argv);

	return 0;
}